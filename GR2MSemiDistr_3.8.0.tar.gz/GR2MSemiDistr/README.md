'GR2MSemiDistr' package
========================
This is a experimental R package for a semi-distributed GR2M hydrological model adaptation using a Weighted Flow Accumulation algorithm for routing discharges.

For any issue or suggestion please write to Harold LLauca (hllauca@gmail.com).

Enjoy it!


Instructions
============
In order to use this package please take a look at the following instructions.

install.packages("devtools")

devtools::install_github("hllauca/GR2MSemiDistr")

library(GR2MSemiDistr)
